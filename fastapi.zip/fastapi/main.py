from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import joblib

# Initialize FastAPI app
app = FastAPI()

# Load the trained BMI model
model = joblib.load("model.joblib")

# Setup templates directory
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "result": None})

@app.post("/predict", response_class=HTMLResponse)
def predict(request: Request, height: float = Form(...), weight: float = Form(...)):
    # BMI model prediction
    prediction = model.predict([[height, weight]])[0]
    return templates.TemplateResponse(
        "index.html",
        {"request": request, "result": round(prediction, 2), "height": height, "weight": weight}
    )
